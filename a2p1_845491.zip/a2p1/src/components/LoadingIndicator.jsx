function LoadingIndicator() {
  return <div>Loading...</div>;
}

export default LoadingIndicator;
