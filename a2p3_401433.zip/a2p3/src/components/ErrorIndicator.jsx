function ErrorIndicator() {
  return <div>Error. .something went wrong</div>;
}

export default ErrorIndicator;
